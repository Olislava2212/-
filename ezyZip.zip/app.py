# app.py - основное приложение
from flask import Flask, render_template, request, jsonify, send_from_directory
import os
from datetime import datetime
import torch
from diffusers import StableDiffusionPipeline
from PIL import Image
import base64
from io import BytesIO
import uuid

app = Flask(__name__)

# Конфигурация
UPLOAD_FOLDER = 'static/generated'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Проверяем доступность GPU
device = "cuda" if torch.cuda.is_available() else "cpu"

# Загрузка модели (в реальном приложении лучше использовать кэширование)
def load_model():
    model_id = "runwayml/stable-diffusion-v1-5"
    pipe = StableDiffusionPipeline.from_pretrained(model_id, torch_dtype=torch.float16 if device == "cuda" else torch.float32)
    pipe = pipe.to(device)
    return pipe

pipe = load_model()

# Генерация изображения
def generate_image(prompt, negative_prompt=None, guidance_scale=7.5, num_inference_steps=50):
    with torch.autocast(device):
        image = pipe(
            prompt,
            negative_prompt=negative_prompt,
            guidance_scale=guidance_scale,
            num_inference_steps=num_inference_steps
        ).images[0]
    return image

# Сохранение изображения и возврат URL
def save_image(image):
    # Создаем уникальное имя файла
    filename = f"generated_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}.png"
    save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    
    # Сохраняем изображение
    image.save(save_path)
    
    # Возвращаем относительный путь
    return f"/generated/{filename}"

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/generate', methods=['POST'])
def generate():
    data = request.json
    prompt = data.get('prompt', '')
    negative_prompt = data.get('negative_prompt', '')
    
    if not prompt:
        return jsonify({'error': 'Prompt is required'}), 400
    
    try:
        # Генерация изображения
        image = generate_image(
            prompt=prompt,
            negative_prompt=negative_prompt
        )
        
        # Сохранение изображения
        image_url = save_image(image)
        
        # Преобразование в base64 для предпросмотра
        buffered = BytesIO()
        image.save(buffered, format="PNG")
        img_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')
        
        return jsonify({
            'image_url': image_url,
            'image_base64': img_base64,
            'prompt': prompt
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/generated/<filename>')
def serve_generated(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)